package me.toot.GUI;


import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import me.toot.utils.utils;

public class EarsMenu2 {
	
	public static Inventory inv;
	public static String inventory_name;
	public static int inv_rows = 6 * 9;
	
	public static void initialize() {
		inventory_name = utils.chat("&aEars  (Page 2)");
		
		inv = Bukkit.createInventory(null, inv_rows);
	}
	public static Inventory GUI(Player p) {
		Inventory toReturn = Bukkit.createInventory(null, inv_rows, inventory_name);
		//Add inv items here!
		
		// Loop Item
		for(int damage = + 1; damage < 46; damage++) {
		//               inv  ID  Damage  Stack  Slot  name  Lore
		    utils.createItem(inv, 290, damage + 47, 1, damage, "&aEars " + damage, "");
		}
		
		// Next Page		
		utils.createItem(inv, 339, 0, 1, 46, "&aPage 1", "");
		
		
		toReturn.setContents(inv.getContents());
		
		return toReturn;
	}
	
	public static void clicked(Player p, int slot, ItemStack clicked, Inventory inv) {
		if (clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.closeInventory();
			p.openInventory(EarsMenu.GUI(p));
		}
		if (!clicked.getItemMeta().getDisplayName().equalsIgnoreCase(utils.chat("&aPage 1"))) {
			p.getInventory().setHelmet(inv.getItem(slot));
		}	}

}
