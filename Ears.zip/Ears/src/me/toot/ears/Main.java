package me.toot.ears;

import org.bukkit.plugin.java.JavaPlugin;

import me.toot.GUI.EarsMenu;
import me.toot.GUI.EarsMenu2;
import me.toot.utils.EarsCommand;
import me.toot.utils.Listeners.InventoryClickListener;

public class Main extends JavaPlugin {
	
	@Override 
	public void onEnable() {
		new EarsCommand(this);
		new InventoryClickListener(this);
		EarsMenu.initialize();
		EarsMenu2.initialize();
	}
    public void onDisable() {
		
	}

}
